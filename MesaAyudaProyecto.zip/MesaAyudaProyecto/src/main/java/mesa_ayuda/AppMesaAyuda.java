package mesa_ayuda;

import java.util.Scanner;

public class AppMesaAyuda {

    private static void mostrarMenu() {
        System.out.println();
        System.out.println("MENU");
        System.out.println("1. Ver tickets en espera");
        System.out.println("2. Ver tickets atendidos");
        System.out.println("3. Ingresar un ticket nuevo");
        System.out.println("4. Atender el siguiente ticket");
        System.out.println("5. Atender todos los tickets en espera");
        System.out.println("6. Auditar tickets atendidos");
        System.out.println("7. Ver tickets auditados");
        System.out.println("0. Salir");
    }

    // Lee un numero entero; retorna -1 si lo escrito no es un numero
    private static int leerEntero(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CRUDTickets crud = new CRUDTickets();
        ManejoPila manejoPila = new ManejoPila();
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero(sc, "Elige una opcion: ");
            System.out.println();

            switch (opcion) {
                case 1:
                    System.out.println("Tickets en espera");
                    crud.mostrarTicketsEnEspera();
                    break;

                case 2:
                    System.out.println("Tickets atendidos");
                    crud.mostrarTicketsAtendidos();
                    break;

                case 3:
                    int id = leerEntero(sc, "Id del ticket (numero mayor que 0): ");
                    if (id <= 0) {
                        System.out.println("Id no valido.");
                        break;
                    }
                    System.out.print("Codigo de incidencia (ej: INC-107): ");
                    String cod = sc.nextLine().trim();
                    if (cod.isEmpty()) {
                        System.out.println("El codigo de incidencia no puede estar vacio.");
                        break;
                    }
                    if (crud.ingresarTicket(id, cod)) {
                        System.out.println("Ticket " + id + " registrado en espera.");
                    } else {
                        System.out.println("Ya existe un ticket con el id " + id + ".");
                    }
                    break;

                case 4:
                    Tickets atendido = crud.AtenderSiguienteTicket();
                    if (atendido == null) {
                        System.out.println("No hay tickets en espera.");
                    } else {
                        System.out.println("Ticket atendido: " + atendido.getIdTicket()
                                + " (" + atendido.getCodIncidencia() + ")");
                    }
                    break;

                case 5:
                    int cantidad = crud.AtenderTodosLosTickets();
                    if (cantidad == 0) {
                        System.out.println("No hay tickets en espera.");
                    } else {
                        System.out.println("Tickets atendidos: " + cantidad);
                    }
                    break;

                case 6:
                    Pila atendidos = crud.extraccionInformacionTicketsAtendidos();
                    if (manejoPila.estaVacia(atendidos)) {
                        System.out.println("No hay tickets atendidos para auditar.");
                        break;
                    }
                    int antes = crud.contarAuditados();
                    Pila pendientes = crud.AuditoriaTickets(atendidos);
                    int nuevos = crud.contarAuditados() - antes;
                    System.out.println("Tickets enviados a auditados.txt: " + nuevos);
                    System.out.println("Tickets que quedan para revision (id fuera de 1 a 50):");
                    manejoPila.mostrar(pendientes);
                    break;

                case 7:
                    System.out.println("Tickets auditados");
                    crud.mostrarTicketsAuditados();
                    break;

                case 0:
                    System.out.println("Cerrando...");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);

        sc.close();
    }
}
