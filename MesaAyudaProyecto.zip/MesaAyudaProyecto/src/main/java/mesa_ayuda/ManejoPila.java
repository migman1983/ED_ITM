package mesa_ayuda;

public class ManejoPila {

    public boolean estaVacia(Pila pila) {
        return pila.getTope() == null;
    }

    public void apilar(Pila pila, Tickets ticket) {
        Nodo nuevo = new Nodo(ticket);
        nuevo.setSiguiente(pila.getTope());
        pila.setTope(nuevo);
        pila.setTamanio(pila.getTamanio() + 1);
    }

    public Tickets desapilar(Pila pila) {
        if (estaVacia(pila)) {
            return null;
        }
        Nodo nodo = pila.getTope();
        pila.setTope(nodo.getSiguiente());
        pila.setTamanio(pila.getTamanio() - 1);
        return nodo.getDato();
    }

    // Recorre la pila sin sacar los elementos
    public void mostrar(Pila pila) {
        if (estaVacia(pila)) {
            System.out.println("No hay tickets para mostrar.");
            return;
        }
        System.out.println(Tickets.encabezado());
        Nodo actual = pila.getTope();
        while (actual != null) {
            System.out.println(actual.getDato().enFila());
            actual = actual.getSiguiente();
        }
    }
}
