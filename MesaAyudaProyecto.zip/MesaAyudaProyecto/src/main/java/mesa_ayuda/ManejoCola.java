package mesa_ayuda;

public class ManejoCola {

    public boolean estaVacia(Cola cola) {
        return cola.getFrente() == null;
    }

    public void encolar(Cola cola, Tickets ticket) {
        Nodo nuevo = new Nodo(ticket);
        if (estaVacia(cola)) {
            cola.setFrente(nuevo);
        } else {
            cola.getFin().setSiguiente(nuevo);
        }
        cola.setFin(nuevo);
        cola.setTamanio(cola.getTamanio() + 1);
    }

    public Tickets desencolar(Cola cola) {
        if (estaVacia(cola)) {
            return null;
        }
        Nodo nodo = cola.getFrente();
        cola.setFrente(nodo.getSiguiente());
        if (cola.getFrente() == null) {
            cola.setFin(null);
        }
        cola.setTamanio(cola.getTamanio() - 1);
        return nodo.getDato();
    }

    // Recorre la cola sin sacar los elementos
    public void mostrar(Cola cola) {
        if (estaVacia(cola)) {
            System.out.println("No hay tickets para mostrar.");
            return;
        }
        System.out.println(Tickets.encabezado());
        Nodo actual = cola.getFrente();
        while (actual != null) {
            System.out.println(actual.getDato().enFila());
            actual = actual.getSiguiente();
        }
    }
}
