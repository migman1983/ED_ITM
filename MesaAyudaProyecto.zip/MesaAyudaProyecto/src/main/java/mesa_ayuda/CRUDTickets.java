package mesa_ayuda;

import java.time.LocalDate;

public class CRUDTickets {
    private static final String RUTA_INGRESADOS = "TicketsIngresados.txt";
    private static final String RUTA_AUDITADOS = "auditados.txt";

    private Archivo archivo = new Archivo();
    private ManejoCola manejoCola = new ManejoCola();
    private ManejoPila manejoPila = new ManejoPila();

    // Convierte una linea del archivo en un objeto Tickets
    private Tickets crearTicket(String linea) {
        String[] d = linea.split(",");
        return new Tickets(Integer.parseInt(d[0].trim()), d[1].trim(),
                           d[2].trim(), d[3].trim());
    }

    // Lee todo el archivo como un arreglo de Tickets
    private Tickets[] leerTodos() {
        String[] lineas = archivo.leer(RUTA_INGRESADOS);
        Tickets[] vec = new Tickets[lineas.length];
        for (int i = 0; i < lineas.length; i++) {
            vec[i] = crearTicket(lineas[i]);
        }
        return vec;
    }

    // Reescribe el archivo completo con el arreglo de tickets
    private void guardarTodos(Tickets[] vec) {
        String[] lineas = new String[vec.length];
        for (int i = 0; i < vec.length; i++) {
            lineas[i] = vec[i].toString();
        }
        archivo.reescribir(RUTA_INGRESADOS, lineas);
    }

    // Indica si un id ya esta registrado en TicketsIngresados.txt
    public boolean existeId(int id) {
        Tickets[] vec = leerTodos();
        for (int i = 0; i < vec.length; i++) {
            if (vec[i].getIdTicket() == id) {
                return true;
            }
        }
        return false;
    }

    // Indica si un id ya fue enviado a auditados.txt
    private boolean yaAuditado(int id) {
        String[] lineas = archivo.leer(RUTA_AUDITADOS);
        for (int i = 0; i < lineas.length; i++) {
            if (crearTicket(lineas[i]).getIdTicket() == id) {
                return true;
            }
        }
        return false;
    }

    public int contarAuditados() {
        return archivo.contarLineas(RUTA_AUDITADOS);
    }


    public Cola extraccionInformacionTicketsEspera() {
        Cola cola = new Cola();
        Tickets[] vec = leerTodos();
        for (int i = 0; i < vec.length; i++) {
            if (vec[i].estaEnEspera()) {
                manejoCola.encolar(cola, vec[i]);
            }
        }
        return cola;
    }

    public Pila extraccionInformacionTicketsAtendidos() {
        Pila pila = new Pila();
        Tickets[] vec = leerTodos();
        for (int i = 0; i < vec.length; i++) {
            if (vec[i].estaAtendido()) {
                manejoPila.apilar(pila, vec[i]);
            }
        }
        return pila;
    }

 
    public void AtencionTickets(Cola cola) {
        Tickets[] vec = leerTodos();
        while (!manejoCola.estaVacia(cola)) {
            Tickets atendido = manejoCola.desencolar(cola);
            atendido.setEstado("Atendido");
            for (int i = 0; i < vec.length; i++) {
                if (vec[i].getIdTicket() == atendido.getIdTicket()) {
                    vec[i] = atendido;
                    break;
                }
            }
            guardarTodos(vec);
        }
    }

  
    public Pila AuditoriaTickets(Pila pila) {
        Pila noCumplen = new Pila();
        while (!manejoPila.estaVacia(pila)) {
            Tickets t = manejoPila.desapilar(pila);
            if (t.getIdTicket() >= 1 && t.getIdTicket() <= 50) {
                if (!yaAuditado(t.getIdTicket())) {
                    archivo.agregar(RUTA_AUDITADOS, t.toString());
                }
            } else {
                manejoPila.apilar(noCumplen, t);
            }
        }
        return noCumplen;
    }


    public void mostrarTicketsEnEspera() {
        manejoCola.mostrar(extraccionInformacionTicketsEspera());
    }

    public void mostrarTicketsAtendidos() {
        manejoPila.mostrar(extraccionInformacionTicketsAtendidos());
    }

    public void mostrarTicketsAuditados() {
        String[] lineas = archivo.leer(RUTA_AUDITADOS);
        if (lineas.length == 0) {
            System.out.println("Todavia no hay tickets auditados.");
            return;
        }
        System.out.println(Tickets.encabezado());
        for (int i = 0; i < lineas.length; i++) {
            System.out.println(crearTicket(lineas[i]).enFila());
        }
    }

    public boolean ingresarTicket(int id, String codIncidencia) {
        if (existeId(id)) {
            return false;
        }
        String cod = codIncidencia.trim().replace(",", " ");
        Tickets nuevo = new Tickets(id, cod, "En espera", LocalDate.now().toString());
        archivo.agregar(RUTA_INGRESADOS, nuevo.toString());
        return true;
    }

    // Atiende solo el primer ticket de la cola. Retorna null si no hay en espera
    public Tickets AtenderSiguienteTicket() {
        Cola espera = extraccionInformacionTicketsEspera();
        if (manejoCola.estaVacia(espera)) {
            return null;
        }
        Tickets primero = manejoCola.desencolar(espera);
        Cola unico = new Cola();
        manejoCola.encolar(unico, primero);
        AtencionTickets(unico);
        return primero;
    }

    // Atiende todos los tickets en espera. Retorna cuantos atendio
    public int AtenderTodosLosTickets() {
        Cola espera = extraccionInformacionTicketsEspera();
        int cantidad = espera.getTamanio();
        AtencionTickets(espera);
        return cantidad;
    }
}
