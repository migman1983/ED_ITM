package mesa_ayuda;

public class Pila {
    private Nodo tope;
    private int tamanio;

    public Pila() {
        this.tope = null;
        this.tamanio = 0;
    }

    public Nodo getTope() { return tope; }
    public void setTope(Nodo tope) { this.tope = tope; }
    public int getTamanio() { return tamanio; }
    public void setTamanio(int tamanio) { this.tamanio = tamanio; }
}
