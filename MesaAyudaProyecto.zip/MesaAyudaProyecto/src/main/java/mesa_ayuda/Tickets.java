package mesa_ayuda;

public class Tickets {
    private int idTicket;
    private String codIncidencia;
    private String estado;
    private String fechaReporte;

    public Tickets(int idTicket, String codIncidencia, String estado, String fechaReporte) {
        this.idTicket = idTicket;
        this.codIncidencia = codIncidencia;
        this.estado = estado;
        this.fechaReporte = fechaReporte;
    }

    public int getIdTicket() { return idTicket; }
    public String getCodIncidencia() { return codIncidencia; }
    public String getEstado() { return estado; }
    public String getFechaReporte() { return fechaReporte; }
    public void setEstado(String estado) { this.estado = estado; }

    public boolean estaEnEspera() {
        return estado.equalsIgnoreCase("En espera") || estado.equalsIgnoreCase("Espera");
    }

    public boolean estaAtendido() {
        return estado.equalsIgnoreCase("Atendido");
    }

    // Formato para guardar en el archivo
    @Override
    public String toString() {
        return idTicket + "," + codIncidencia + "," + estado + "," + fechaReporte;
    }

    // Formato para mostrar en pantalla
    public static String encabezado() {
        return String.format("%-6s %-12s %-10s %s", "ID", "Incidencia", "Estado", "Fecha");
    }

    public String enFila() {
        return String.format("%-6d %-12s %-10s %s", idTicket, codIncidencia, estado, fechaReporte);
    }
}
