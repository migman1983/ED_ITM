package mesa_ayuda;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Archivo {

    // Cuenta las lineas no vacias del archivo
    public int contarLineas(String ruta) {
        int cont = 0;
        File f = new File(ruta);
        if (!f.exists()) {
            return 0;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    cont++;
                }
            }
        } catch (IOException e) {
            System.out.println("Error al contar " + ruta + ": " + e.getMessage());
        }
        return cont;
    }

    // Lee todas las lineas no vacias del archivo en un arreglo
    public String[] leer(String ruta) {
        String[] lineas = new String[contarLineas(ruta)];
        File f = new File(ruta);
        if (!f.exists()) {
            return lineas;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            int i = 0;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    lineas[i] = linea;
                    i++;
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer " + ruta + ": " + e.getMessage());
        }
        return lineas;
    }

    // Sobrescribe el archivo con las lineas del arreglo
    public void reescribir(String ruta, String[] lineas) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta, false))) {
            for (int i = 0; i < lineas.length; i++) {
                pw.println(lineas[i]);
            }
        } catch (IOException e) {
            System.out.println("Error al escribir " + ruta + ": " + e.getMessage());
        }
    }

    // Agrega una linea al final del archivo
    public void agregar(String ruta, String linea) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta, true))) {
            pw.println(linea);
        } catch (IOException e) {
            System.out.println("Error al agregar en " + ruta + ": " + e.getMessage());
        }
    }
}
