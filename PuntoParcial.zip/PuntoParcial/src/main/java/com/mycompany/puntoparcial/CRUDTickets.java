package com.mycompany.puntoparcial;

public class CRUDTickets 
{
    // 1. Método: GestionarTicketsEnEspera
    public Cola gestionarTicketsEnEspera(Archivo archivo) 
    {
        archivo.abrirModoLectura("TicketsIngresados.txt");
        int tamanoVector = archivo.contarLineas("TicketsIngresados.txt");
        Ticket[] vectorTickets = new Ticket[tamanoVector];
        vectorTickets = archivo.leerTickets("TicketsIngresados.txt");
        archivo.cerrarModoLectura();

        int contadorEnEspera = 0;
        for (int i = 0; i < vectorTickets.length; i++) 
        {
            if (vectorTickets[i].obtenerEstado().equals("en espera")) 
            {
                contadorEnEspera++;
            }
        }

        Cola colaEspera = new Cola(contadorEnEspera);

        for (int i = 0; i < vectorTickets.length; i++) 
        {
            if (vectorTickets[i].obtenerEstado().equals("en espera")) 
            {
                colaEspera.encolar(vectorTickets[i]);
            }
        }

        return colaEspera;
    }

    // 2. Método: GestionarTicketsAtendidos
    public Pila gestionarTicketsAtendidos(Archivo archivo) 
    {
        archivo.abrirModoLectura("TicketsIngresados.txt");
        int tamanoVector = archivo.contarLineas("TicketsIngresados.txt");
        Ticket[] vectorTickets = new Ticket[tamanoVector];
        vectorTickets = archivo.leerTickets("TicketsIngresados.txt");
        archivo.cerrarModoLectura();

        int contadorAtendidos = 0;
        for (int i = 0; i < vectorTickets.length; i++) 
        {
            if (vectorTickets[i].obtenerEstado().equals("atendido")) 
            {
                contadorAtendidos++;
            }
        }

        Pila pilaAtendidos = new Pila(contadorAtendidos);

        for (int i = 0; i < vectorTickets.length; i++)
        {
            if (vectorTickets[i].obtenerEstado().equals("atendido")) 
            {
                pilaAtendidos.apilar(vectorTickets[i]);
            }
        }

        return pilaAtendidos;
    }

    // 3. Método: AtenderTickets
    public void atenderTickets(Archivo archivo, Cola colaEspera) 
    {
        Ticket ticket;
        
        archivo.abrirModoEscritura("TicketsIngresados.txt");
        
        while (!colaEspera.estaVacia()) 
        {
            ticket = (Ticket) colaEspera.pop();
            ticket.asignarEstado("atendido");
            archivo.escribir(ticket.toString());
        }
        
        archivo.cerrarModoEscritura();
    }

    // 4. Método: ProcesarAuditoria
    public Pila procesarAuditoria(Archivo archivo, Pila pilaAtendidos) 
    {
        Ticket ticket;
        Pila pilaAuxiliar = new Pila(pilaAtendidos.obtenerTamano());
        
        archivo.abrirModoEscritura("auditados.txt");
        
        while (!pilaAtendidos.estaVacia()) 
        {
            ticket = (Ticket) pilaAtendidos.pop();
            
            if (ticket.obtenerCodigoIncidencia() >= 1 && ticket.obtenerCodigoIncidencia() <= 50) 
            {
                archivo.escribir(ticket.toString());
            } else 
            {
                pilaAuxiliar.push(ticket);
            }
        }

        archivo.cerrarModoEscritura();
        
        return pilaAuxiliar;
    }
}
