
package com.mycompany.puntoparcial;

public class PuntoParcial 
{

    public static void main(String[] args) 
    {
        CRUDTickets gestorTickets = new CRUDTickets();
        Archivo archivo = new Archivo();

        // 1. Extraer los tickets que se encuentran "en espera"
        Cola ticketsEspera = gestorTickets.gestionarTicketsEnEspera(archivo);

        // 2. Procesar y atender los tickets en espera (actualiza el archivo principal)
        gestorTickets.atenderTickets(archivo, ticketsEspera);

        // 3. Extraer los tickets cuyo estado haya sido actualizado a "atendido"
        Pila ticketsAtendidos = gestorTickets.gestionarTicketsAtendidos(archivo);

        // 4. Auditar los tickets atendidos
        Pila ticketsParaRevision = gestorTickets.procesarAuditoria(archivo, ticketsAtendidos);
    }
}
