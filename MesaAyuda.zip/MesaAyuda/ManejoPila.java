public class ManejoPila {

    public void mostrar(Pila p) {
        Pila aux = new Pila();
        if (p.isEmpty()) {
            System.out.println("  (pila vacía)");
        }
        while (!p.isEmpty()) {
            Object dato = p.pop();
            System.out.println("  " + dato);
            aux.push(dato);
        }
        while (!aux.isEmpty()) {
            p.push(aux.pop());
        }
    }

    public int tamaño(Pila p) {
        Pila aux = new Pila();
        int cont = 0;
        while (!p.isEmpty()) {
            aux.push(p.pop());
            cont++;
        }
        while (!aux.isEmpty()) {
            p.push(aux.pop());
        }
        return cont;
    }
}
