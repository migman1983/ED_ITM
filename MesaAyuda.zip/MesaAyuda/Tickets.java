public class Tickets {
    private int idTicket;
    private int codIncidencia;
    private String estado;
    private String fechaReporte;

    public Tickets(int idTicket, int codIncidencia, String estado, String fechaReporte) {
        this.idTicket = idTicket;
        this.codIncidencia = codIncidencia;
        this.estado = estado;
        this.fechaReporte = fechaReporte;
    }

    public int obtenerIdTicket() {
        return idTicket;
    }

    public int obtenerCodIncidencia() {
        return codIncidencia;
    }

    public String obtenerEstado() {
        return estado;
    }

    public String obtenerFechaReporte() {
        return fechaReporte;
    }

    public void asignarEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return idTicket + "," + codIncidencia + "," + estado + "," + fechaReporte;
    }
}
