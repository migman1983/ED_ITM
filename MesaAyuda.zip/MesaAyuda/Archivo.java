import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Archivo {
    private BufferedReader lector;
    private PrintWriter escritor;
    private String nombreLectura;

    public void abrirModoLectura(String nombre) {
        try {
            nombreLectura = nombre;
            lector = new BufferedReader(new FileReader(nombre));
        } catch (IOException e) {
            System.out.println("No se pudo abrir " + nombre + ": " + e.getMessage());
        }
    }

    public int contadorLineas(String nombre) {
        int cont = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(nombre))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    cont++;
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo contar las líneas de " + nombre);
        }
        return cont;
    }

    public Tickets[] leer() {
        int cl = contadorLineas(nombreLectura);
        Tickets[] vec = new Tickets[cl];
        try {
            String linea;
            int i = 0;
            while ((linea = lector.readLine()) != null && i < cl) {
                if (linea.trim().isEmpty()) {
                    continue;
                }
                String[] datos = linea.split(",");
                int id = Integer.parseInt(datos[0].trim());
                int cod = Integer.parseInt(datos[1].trim());
                String estado = datos[2].trim();
                String fecha = datos[3].trim();
                vec[i] = new Tickets(id, cod, estado, fecha);
                i++;
            }
        } catch (IOException e) {
            System.out.println("Error leyendo el archivo: " + e.getMessage());
        }
        return vec;
    }

    public void cerrarModoLectura() {
        try {
            if (lector != null) {
                lector.close();
            }
        } catch (IOException e) {
            System.out.println("Error cerrando el archivo de lectura");
        }
    }

    public void abrirModoEscritura(String nombre) {
        try {
            escritor = new PrintWriter(new FileWriter(nombre, false));
        } catch (IOException e) {
            System.out.println("No se pudo abrir " + nombre + " para escritura");
        }
    }

    public void escribir(String linea) {
        escritor.println(linea);
    }

    public void cerrarModoEscritura() {
        if (escritor != null) {
            escritor.close();
        }
    }
}
