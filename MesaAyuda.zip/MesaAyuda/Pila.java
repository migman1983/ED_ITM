public class Pila {
    private Nodo tope;

    public Pila() {
        tope = null;
    }

    public void push(Object dato) {
        Nodo nuevo = new Nodo(dato);
        nuevo.setSiguiente(tope);
        tope = nuevo;
    }

    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        Object dato = tope.getDato();
        tope = tope.getSiguiente();
        return dato;
    }

    public boolean isEmpty() {
        return tope == null;
    }
}
