public class ManejoCola {

    public void mostrar(Cola c) {
        Cola aux = new Cola();
        if (c.isEmpty()) {
            System.out.println("  (cola vacía)");
        }
        while (!c.isEmpty()) {
            Object dato = c.pop();
            System.out.println("  " + dato);
            aux.push(dato);
        }
        while (!aux.isEmpty()) {
            c.push(aux.pop());
        }
    }

    public int tamaño(Cola c) {
        Cola aux = new Cola();
        int cont = 0;
        while (!c.isEmpty()) {
            aux.push(c.pop());
            cont++;
        }
        while (!aux.isEmpty()) {
            c.push(aux.pop());
        }
        return cont;
    }
}
