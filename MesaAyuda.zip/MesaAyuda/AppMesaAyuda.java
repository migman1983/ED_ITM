import java.util.Scanner;

public class AppMesaAyuda {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Archivo objA = new Archivo();
        CRUDTickets crud = new CRUDTickets();
        ManejoCola mCola = new ManejoCola();
        ManejoPila mPila = new ManejoPila();

        Cola colaEspera = null;
        Pila pilaAtendidos = null;
        Pila pilaPendientes = null;

        int op;
        do {
            System.out.println("\n===== MESA DE AYUDA =====");
            System.out.println("1. Extraer tickets en espera");
            System.out.println("2. Atender tickets en espera");
            System.out.println("3. Extraer tickets atendidos");
            System.out.println("4. Auditar tickets atendidos");
            System.out.println("0. Salir");
            System.out.print("Ingrese la opción: ");

            while (!sc.hasNextInt()) {
                System.out.print("Ingrese un número válido: ");
                sc.next();
            }
            op = sc.nextInt();

            switch (op) {
                case 1:
                    colaEspera = crud.extraccionInformacionTicketsEspera(objA);
                    mCola.mostrar(colaEspera);
                    break;

                case 2:
                    if (colaEspera == null || colaEspera.isEmpty()) {
                        System.out.println("Primero ejecute la opción 1 o no hay tickets en espera.");
                    } else {
                        crud.atencionTickets(objA, colaEspera);
                        System.out.println("Tickets atendidos y archivo actualizado.");
                    }
                    break;

                case 3:
                    pilaAtendidos = crud.extraccionInformacionTicketsAtendidos(objA);
                    mPila.mostrar(pilaAtendidos);
                    break;

                case 4:
                    if (pilaAtendidos == null || pilaAtendidos.isEmpty()) {
                        System.out.println("Primero ejecute la opción 3 o no hay tickets atendidos.");
                    } else {
                        pilaPendientes = crud.auditoriaTickets(objA, pilaAtendidos);
                        System.out.println("Auditoría realizada. Revise auditados.txt.");
                        if (!pilaPendientes.isEmpty()) {
                            System.out.println("Tickets pendientes para posterior revisión:");
                            mPila.mostrar(pilaPendientes);
                        }
                    }
                    break;

             

                default:
                    System.out.println("Opción no válida.");
            }
        } while (op != 0);

        sc.close();
    }
}
